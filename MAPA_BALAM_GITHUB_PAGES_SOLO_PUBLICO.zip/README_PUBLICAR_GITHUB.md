# MAPA BALAM · Paquete para GitHub Pages

Este directorio es el **ÚNICO** componente preparado para publicación pública.

## Publicar con interfaz web de GitHub
1. Crea un repositorio nuevo, por ejemplo `mapa-balam-ds05`, en **tu propia cuenta de GitHub**. No lo confundas con `aocejogarcia/polo_rev`, cuyo código es de otro repositorio.
2. Sube **únicamente el contenido de esta carpeta** al directorio raíz del repositorio: `index.html`, `atlas/`, `assets/` y `data/atlas/`. Conserva las carpetas y archivos `.geojson.gz`.
3. En **Settings → Pages**, elige `Deploy from a branch`, rama `main`, carpeta `/(root)` y guarda.
4. Tras finalizar el despliegue, abre la dirección Pages que GitHub te proporcione. Prueba seleccionar Navojoa y consultar el censo territorial.
5. El enlace a Polo REV abrirá la aplicación original en una pestaña separada. No se incrustan sitios externos.

## Seguridad
**NO** publiques el archivo `cabina_original_v494.html`, `data/private/`, el ZIP completo, los registros nominales SIESA ni datos operativos agregados sin revisión y autorización.

El visor público ofrece cartografía censal y prepara la estructura para sumar indicadores *después* de una revisión de divulgación, privacidad y exactitud geográfica. El proyecto no ha sido publicado automáticamente en tu GitHub.

## Técnicas
El visor Atlas público utiliza Canvas 2D, geometría GeoJSON y archivos gzip cargados progresivamente. Si tu navegador rechaza la descompresión, prueba Chrome o Edge actualizado.
